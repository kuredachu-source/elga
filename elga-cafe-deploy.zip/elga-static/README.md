# ELGA CAFE — Deploy to Vercel

## This is a pre-built static site. No build step needed.

### Deploy in 2 steps:

**Step 1 — GitHub**
1. Create a new GitHub repo called `elga-cafe`
2. Upload ALL files from this folder (index.html, vercel.json, dist/)
   - Make sure the `dist/` folder with `bundle.js` is uploaded too
3. Commit

**Step 2 — Vercel**
1. vercel.com → Add New Project → import `elga-cafe`
2. Under "Build & Output Settings":
   - Build Command: leave BLANK (delete anything there)
   - Output Directory: leave BLANK
3. Click Deploy

Done. Your site is live.

### How QR works:
- Staff Terminal → QR Generator → generate for any table
- QR encodes your real Vercel URL automatically
- Customer scans → opens Customer Menu for that table ✅
